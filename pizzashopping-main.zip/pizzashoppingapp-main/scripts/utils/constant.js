const url = 'https://raw.githubusercontent.com/Skill-risers/pizzajson/main/pizza.json';
export default url;//doesnt wrapped into object
//module.exports = url;